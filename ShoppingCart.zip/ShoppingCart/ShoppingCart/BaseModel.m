//
//  BaseModel.m
//  ShoppingCart
//
//  Created by zeasn on 17/2/8.
//  Copyright © 2017年 zeasn. All rights reserved.
//

#import "BaseModel.h"

@implementation BaseModel

@end
