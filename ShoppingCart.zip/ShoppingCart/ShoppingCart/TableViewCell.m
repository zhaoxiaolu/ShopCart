//
//  TableViewCell.m
//  ShoppingCart
//
//  Created by zeasn on 17/2/8.
//  Copyright © 2017年 zeasn. All rights reserved.
//

#import "TableViewCell.h"

@implementation TableViewCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        [self initView];
    }
    return self;
}
- (void)initView
{
    //选择按钮
    UIImageView *selectImgView=[[UIImageView alloc]init];
    selectImgView.tag=100;
    UITapGestureRecognizer *tap=[[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(productSelect)];
    [selectImgView addGestureRecognizer:tap];
    selectImgView.userInteractionEnabled=YES;
    [self.contentView addSubview:selectImgView];
    //商品图片
    UIImageView *goodsImgView=[[UIImageView alloc]init];
    goodsImgView.tag=101;
    [self.contentView addSubview:goodsImgView];
    //价格
    UILabel *priceLab=[[UILabel alloc]init];
    priceLab.tag=102;
    priceLab.font=[UIFont systemFontOfSize:10];
    priceLab.textColor=[UIColor redColor];
    [self.contentView addSubview:priceLab];
    //描述
    UILabel *describeLab=[[UILabel alloc]init];
    describeLab.tag=103;
    describeLab.font=[UIFont systemFontOfSize:10];
    describeLab.textColor=[UIColor blackColor];
    [self.contentView addSubview:describeLab];
    //规格
    UILabel *specificationsLab=[[UILabel alloc]init];
    specificationsLab.tag=104;
    specificationsLab.font=[UIFont systemFontOfSize:10];
    specificationsLab.textColor=[UIColor blackColor];
    [self.contentView addSubview:specificationsLab];
    //数量
    UILabel *numLab=[[UILabel alloc]init];
    numLab.tag=105;
    numLab.font=[UIFont systemFontOfSize:10];
    numLab.textColor=[UIColor redColor];
    numLab.textAlignment=NSTextAlignmentRight;
    [self.contentView addSubview:numLab];
    //减按钮
    UIButton *reductionBtn=[[UIButton alloc]initWithFrame:CGRectMake(41+86+10,103-10-21 , 21, 21)];
    [reductionBtn setBackgroundImage:[UIImage imageNamed:@"ShopCart-_def@2x.png"] forState:UIControlStateNormal];
    [reductionBtn addTarget:self action:@selector(reduction) forControlEvents:UIControlEventTouchUpInside];
    [self.contentView addSubview:reductionBtn];
    //加减个数
    UILabel *lab=[[UILabel alloc]initWithFrame:CGRectMake(41+86+10+21, 103-10-21, 30, 21)];
    lab.text=@"1";
    lab.textColor=[UIColor redColor];
    lab.textAlignment=NSTextAlignmentCenter;
    lab.font=[UIFont systemFontOfSize:10];
    [self.contentView addSubview:lab];
    //增加按钮
    UIButton *addBtn=[[UIButton alloc]initWithFrame:CGRectMake(41+86+10+21+30,103-10-21, 21, 21)];
    [addBtn setBackgroundImage:[UIImage imageNamed:@"ShopCart+_def"] forState:UIControlStateNormal];
    [addBtn addTarget:self action:@selector(add) forControlEvents:UIControlEventTouchUpInside];
    [self.contentView addSubview:addBtn];
    //删除按钮
    UIButton *deleteBtn=[[UIButton alloc]initWithFrame:CGRectMake(kScreenWidth-13-21,103-10-21, 21, 21)];
    deleteBtn.backgroundColor=[UIColor blueColor];
    [deleteBtn addTarget:self action:@selector(delete) forControlEvents:UIControlEventTouchUpInside];
    [self.contentView addSubview:deleteBtn];
    

}
- (void)layoutSubviews
{
    [super layoutSubviews];
    //选择按钮
     UIImageView  *selectImgView = [self.contentView viewWithTag:100];
    selectImgView.frame=CGRectMake(0, 0, 41, 103);
    
    if(self.baseModel.isSelect)
    {
        selectImgView.image =[UIImage imageNamed:@"select-one_on"];
    
    }else
    {
        selectImgView.image=[UIImage imageNamed:@"select-one"];
    }
    //商品按钮
    UIImageView *goodsImtView=[self.contentView viewWithTag:101];
    goodsImtView.frame=CGRectMake(41, 10, 86, 83);
    goodsImtView.backgroundColor=[UIColor redColor];
    goodsImtView.image=[UIImage imageNamed:self.baseModel.imageName];
    //价格
    UILabel *priceLab=[self.contentView viewWithTag:102];
    priceLab.text=[NSString stringWithFormat:@"￥%.2f",self.baseModel.goodsPrice];
    CGSize priceLabSize=[self sizeWithString:priceLab.text font:priceLab.font size:CGSizeMake(100, 20)];
    priceLab.frame=CGRectMake(kScreenWidth-13-priceLabSize.width, 10, priceLabSize.width, 20);
    //描述
    UILabel *describeLab=[self.contentView viewWithTag:103];
    describeLab.frame=CGRectMake(41+86+10, 10, kScreenWidth-41-86-10-priceLabSize.width, 20);
    describeLab.text=self.baseModel.describe;
    //规格
    UILabel *specificationsLab=[self.contentView viewWithTag:104];
    specificationsLab.frame=CGRectMake(41+86+10, 10+20+10, 200, 20);
    specificationsLab.text=[NSString stringWithFormat:@"规格%@",self.baseModel.specifications];
    //数量
    UILabel *numLab=[self.contentView viewWithTag:105];
    numLab.frame=CGRectMake(kScreenWidth-13-50, 10+20+10, 50, 20);
    numLab.text=[NSString stringWithFormat:@"x%ld",self.baseModel.goodsNum];
    

}
//选择的事件
- (void)productSelect
{
    [self blockNum:@"1"];
}
//减法
- (void)reduction
{
    if (self.baseModel.goodsNum<=1)//购买个数不能小于1
    {
     
    }else
    {
        [self blockNum:@"2"];
    }
}
//加法
- (void)add
{
    [self blockNum:@"3"];
}
//删除
- (void)delete
{
 [self blockNum:@"4"];
}

//block回调方法
- (void)blockNum:(NSString *)blockName
{
    NSArray *keyArr=@[@"blockName",@"row"];//blockName 1代表选择按钮  2代表减  3代表加 4代表删除
    NSArray *valueArr=@[blockName,[NSString stringWithFormat:@"%ld",(long)_row]];
    NSDictionary *dic=[NSDictionary dictionaryWithObjects:valueArr forKeys:keyArr];
    if (self.passingTextBlock != nil) {
        self.passingTextBlock(dic);
    }
    
}
// Label自适应
#pragma mark-计算文字的长度和宽度
-(CGSize)sizeWithString:(NSString *)string font:(UIFont *)font size:(CGSize)size
{
    CGRect rect = [string boundingRectWithSize:size//限制最大的宽度和高度
                                       options:NSStringDrawingTruncatesLastVisibleLine | NSStringDrawingUsesFontLeading  |NSStringDrawingUsesLineFragmentOrigin//采用换行模式
                                    attributes:@{NSFontAttributeName: font}//传入的字体字典
                                       context:nil];
    return rect.size;
}
- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
