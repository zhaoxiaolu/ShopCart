//
//  ViewController.h
//  ShoppingCart
//
//  Created by zeasn on 17/2/8.
//  Copyr/Users/zeasn/Desktop/ShoppingCart/ShoppingCart/ViewController.might © 2017年 zeasn. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BaseModel.h"
#import "TableViewCell.h"
//获取物理屏幕的尺寸
#define kScreenHeight ([UIScreen mainScreen].bounds.size.height)
#define kScreenWidth ([UIScreen mainScreen].bounds.size.width)
@interface ViewController : UIViewController<UITableViewDelegate,UITableViewDataSource>
{
    NSMutableArray *dataListArr;//数据
    UITableView *shoppingCartTab;
    UIButton *allSelectBtn;//最下方全选按钮
    UILabel *totalPriceLab;//最下方总价格
}
@property (nonatomic, assign) BOOL isAllSelect;//判断是否为全选用
@end

