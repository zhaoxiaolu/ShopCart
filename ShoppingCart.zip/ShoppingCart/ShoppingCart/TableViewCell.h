//
//  TableViewCell.h
//  ShoppingCart
//
//  Created by zeasn on 17/2/8.
//  Copyright © 2017年 zeasn. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BaseModel.h"
//获取物理屏幕的尺寸
#define kScreenHeight ([UIScreen mainScreen].bounds.size.height)
#define kScreenWidth ([UIScreen mainScreen].bounds.size.width)
//block  加减  选择   删除 使用
typedef void (^PassingTextBlock)(NSDictionary *dic);
@interface TableViewCell : UITableViewCell

@property (nonatomic, strong) BaseModel *baseModel;
@property (nonatomic, assign) NSInteger row;//当前的行数
@property (nonatomic, copy) PassingTextBlock passingTextBlock;

@end
