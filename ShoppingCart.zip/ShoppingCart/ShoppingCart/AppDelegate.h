//
//  AppDelegate.h
//  ShoppingCart
//
//  Created by zeasn on 17/2/8.
//  Copyright © 2017年 zeasn. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

