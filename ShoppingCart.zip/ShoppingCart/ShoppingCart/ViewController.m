//
//  ViewController.m
//  ShoppingCart
//
//  Created by zeasn on 17/2/8.
//  Copyright © 2017年 zeasn. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self dataProcessing];
    [self createView];
    // Do any additional setup after loading the view, typically from a nib.
}

#pragma mark-数据处理
- (void)dataProcessing
{

    dataListArr=[NSMutableArray array];
    for (int i=0; i<10; i++)
    {
        BaseModel *baseModel=[[BaseModel alloc]init];
        baseModel.isSelect=NO;
        baseModel.imageName=@"xiajia";
        baseModel.describe=@"买猪了！！！！谁要猪！！！！";
        baseModel.goodsPrice=0.01;
        baseModel.specifications=@"400*600";
        baseModel.goodsNum=2;
        [dataListArr addObject:baseModel];
    }
    [shoppingCartTab reloadData];
}
#pragma mark-页面布局
- (void)createView
{
    shoppingCartTab=[[UITableView alloc]initWithFrame:CGRectMake(0, 64, kScreenWidth, kScreenHeight-64-50)];
    shoppingCartTab.dataSource=self;
    shoppingCartTab.delegate=self;
//    shoppingCartTab.backgroundColor=[UIColor clearColor];
    [self.view addSubview:shoppingCartTab];
    //下方全选按钮
    allSelectBtn=[[UIButton alloc]initWithFrame:CGRectMake(0, kScreenHeight-64-10, 41, 103)];
    [allSelectBtn setImage:[UIImage imageNamed:@"select-one"] forState:UIControlStateNormal];
    [allSelectBtn addTarget:self action:@selector(allSelect) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:allSelectBtn];
    //下方总的价格
    totalPriceLab=[[UILabel alloc]initWithFrame:CGRectMake(kScreenWidth-200, kScreenHeight-50, 200, 50)];
    totalPriceLab.textColor=[UIColor redColor];
    totalPriceLab.font=[UIFont systemFontOfSize:15];
    totalPriceLab.text=@"合计:￥0.00";
    
//    totalPriceLab.backgroundColor=[UIColor redColor];
    [self.view addSubview:totalPriceLab];
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 103;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{

    return dataListArr.count;
}

// Row display. Implementers should *always* try to reuse cells by setting each cell's reuseIdentifier and querying for available reusable cells with dequeueReusableCellWithIdentifier:
// Cell gets various attributes set automatically based on table (separators) and data source (accessory views, editing controls)

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *identifier = @"shopcartCell";
    TableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    if (cell == nil) {
        cell = [[TableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier];
        cell.backgroundColor = [UIColor clearColor];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        
    }
    cell.baseModel = dataListArr[indexPath.row];
    cell.row = indexPath.row;
    __weak typeof(self) wself = self;
    cell.passingTextBlock = ^(NSDictionary *dic)
    {
        [wself cellBlockHandle:dic];
    };

    return  cell;
}
//cell的block回调处理
- (void)cellBlockHandle:(NSDictionary *)dic
{
    //blockName 1代表选择按钮  2代表减  3代表加 4代表删除
    NSString *blockName = [dic objectForKey:@"blockName"];
    NSInteger row = [[dic objectForKey:@"row"] integerValue];
    BaseModel *baseModel = dataListArr[row];
    if ([blockName isEqualToString:@"1"])//选择按钮处理
    {
        
        baseModel.isSelect=!baseModel.isSelect;
        [dataListArr replaceObjectAtIndex:row withObject:baseModel];
        
    }
    else if ([blockName isEqualToString:@"2"])//减
    {
        baseModel.goodsNum=baseModel.goodsNum-1;
        [dataListArr replaceObjectAtIndex:row withObject:baseModel];
    }
    else if ([blockName isEqualToString:@"3"])//加
    {
        baseModel.goodsNum=baseModel.goodsNum+1;
        [dataListArr replaceObjectAtIndex:row withObject:baseModel];
    }else
    {
        [dataListArr removeObjectAtIndex:row];
    }
    [self decideEvent];
    [self calculatePriceSelection];
    [shoppingCartTab reloadData];
}
#pragma mark-单个选择时判断是否为全选
- (void)decideEvent
{
    for (BaseModel *baseModel in dataListArr)
    {
        if (baseModel.isSelect)
        {
            _isAllSelect=YES;
        }else
        {
            _isAllSelect=NO;
            break;
        }
    }
    if (_isAllSelect) {
        [allSelectBtn setImage:[UIImage imageNamed:@"select-one_on"] forState:UIControlStateNormal];
    }else
    {
        [allSelectBtn setImage:[UIImage imageNamed:@"select-one"] forState:UIControlStateNormal];
    }

}

#pragma mark-全选按钮
- (void)allSelect
{
    _isAllSelect=!_isAllSelect;
    for (int i=0; i<dataListArr.count; i++)
    {
         BaseModel *baseModel=dataListArr[i];
            baseModel.isSelect=_isAllSelect;
         [dataListArr replaceObjectAtIndex:i withObject:baseModel];
    }
    if (_isAllSelect)
    {
        [allSelectBtn setImage:[UIImage imageNamed:@"select-one_on"] forState:UIControlStateNormal];
    }else
    {
        [allSelectBtn setImage:[UIImage imageNamed:@"select-one"] forState:UIControlStateNormal];
    
    }
    [self calculatePriceSelection];
    [shoppingCartTab reloadData];
}
#pragma  mark -判断选择哪个商品 并且计算价钱
- (void)calculatePriceSelection
{
    double price=0.00;
    for (BaseModel *baseModel in dataListArr)
    {
        if (baseModel.isSelect)
        {
            price=price+(baseModel.goodsPrice*baseModel.goodsNum);
        }
    }
    
     totalPriceLab.text=[NSString stringWithFormat:@"合计:￥%.2f",price];

}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
