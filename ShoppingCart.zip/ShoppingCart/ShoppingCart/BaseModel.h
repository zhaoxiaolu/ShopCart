//
//  BaseModel.h
//  ShoppingCart
//
//  Created by zeasn on 17/2/8.
//  Copyright © 2017年 zeasn. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface BaseModel : NSObject
@property (nonatomic, assign) BOOL isSelect;//是否被选择
@property (nonatomic, assign) double goodsPrice;//商品价格
@property (nonatomic, assign) NSInteger goodsNum;//商品数量
@property (nonatomic, copy) NSString *imageName;//图片
@property (nonatomic, copy) NSString *describe;//描述
@property (nonatomic, copy) NSString *specifications;//规格

@end
